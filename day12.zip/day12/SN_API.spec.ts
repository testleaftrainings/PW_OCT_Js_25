import test, { expect } from '@playwright/test'
import { request } from 'http'

const user="admin"
const pass="tj6Z5^xHfIH+"
const basicInfo=`${user}:${pass}`
const info=btoa(basicInfo)

let Id:any
test("Create a Resources with ServiceNow",async({request})=>{

const response= await request.post("https://dev354719.service-now.com/api/now/table/incident",{

    headers:{
"Content-Type":"application/json",
"Authorization":`Basic ${info}`
    },
    data:{
        "short_description": "Learn API with Playwright"
    }
})

const resBody=await response.json()
//console.log(resBody)
Id=resBody.result.sys_id
//console.log(Id)

expect(response.statusText()).toBe("Created")
expect(response.status()).toBe(201)
})

test("Get Request",async({request})=>{
    const response= await request.get(`https://dev354719.service-now.com/api/now/table/incident/${Id}`,{
        headers:{
            "Content-Type":"application/json",
"Authorization":`Basic ${info}`
        }
    })
    const res=await response.json()
    console.log(res)
    expect(response.status()).toBe(200)
})