import test from '@playwright/test'

let access_Token:any
let inst_Url:any
let token:any
let Id:any

test("Generate the Token",async({request})=>{
    //endpoint uri, headers, body -> urlencodex

    const responToken=await request.post("https://login.salesforce.com/services/oauth2/token",{
        headers:{
            "Content_Type":"application/x-www-form-urlencoded",
            "Connection":"keep-alive"
        },
        form:{
            "grant_type":"password",
            "username":"gauthami.vn@testleaf.com",
            "password":"Qeagle@2025",
            "client_id":"3MVG9rZjd7MXFdLhTFd7jYNtTiu5DzDqdNCte5DvFnv7tbIspjQ9CGPizYGUq7h6T69VSmfqxT9yY2NS7tz84",
            "client_secret":"09FE1EF4BDD93B17821073243A441F8A780A639C21D925B575C1112A3F5E0DBE"
        }
    })

    const info=await responToken.json()
    console.log(info)

    access_Token=info.access_token 
    inst_Url=info.instance_url
    token=info.token_type
})


test("Create Lead",async({request})=>{

const response=await request.post(`${inst_Url}/services/data/v64.0/sobjects/Lead`,{
headers:{
    "Content_Type":"application/json",
    "Authorization":`${token} ${access_Token}`
},
data:{
     "firstname":"Dilip",
    "lastname":"kumar",
    "company":"TestLeaf"
}

})

const res=await response.json()
Id=res.id
console.log(Id)


})